/*************************************************************************
【文件名】CountFixedElement3D.cpp
【功能模块和目的】定义CountFixedElement3D类的成员函数
【开发者及日期】谭雯心 2024/8/5
【更改记录】
*************************************************************************/
#include "CountFixedElement3D.hpp"

using namespace std;

//-------------------------------------------------------------------------
// 内嵌异常类
//-------------------------------------------------------------------------

/*************************************************************************
【函数名称】POINT_COUNT_IS_FIXED
【函数功能】带参构造函数，用于初始化POINT_COUNT_IS_FIXED类的对象
【参数】无
【返回值】无
【开发者及日期】谭雯心 2024/8/5
【更改记录】
*************************************************************************/
CountFixedElement3D::POINT_COUNT_IS_FIXED::POINT_COUNT_IS_FIXED()
    : logic_error("Point count is fixed.") {}

//-------------------------------------------------------------------------
// 必要的构造、析构、拷贝、赋值运算符重载函数
//-------------------------------------------------------------------------

/*************************************************************************
【函数名称】CountFixedElement3D
【函数功能】带参构造函数，用于初始化CountFixedElement3D类的对象
【参数】initializer_list<Point3D> ilist, 表示Point3D类的对象的列表
【返回值】无
【开发者及日期】谭雯心 2024/8/5
【更改记录】
*************************************************************************/
CountFixedElement3D::CountFixedElement3D(initializer_list<Point3D> ilist)
    : Element3D(ilist) {}
/*************************************************************************
【函数名称】CountFixedElement3D
【函数功能】拷贝构造函数，用于初始化CountFixedElement3D类的对象
【参数】const CountFixedElement3D& ACountFixedElement3D,
表示另一个CountFixedElement3D类的对象 【返回值】无 【开发者及日期】谭雯心
2024/8/5 【更改记录】
*************************************************************************/
CountFixedElement3D::CountFixedElement3D(
    const CountFixedElement3D& ACountFixedElement3D)
    : Element3D(ACountFixedElement3D) {}
/*************************************************************************
【函数名称】operator=
【函数功能】重载赋值运算符，
    用于将一个CountFixedElement3D类的对象赋值给另一个CountFixedElement3D类的对象
【参数】const CountFixedElement3D& ACountFixedElement3D,
表示另一个CountFixedElement3D类的对象 【返回值】无 【开发者及日期】谭雯心
2024/8/5 【更改记录】
*************************************************************************/
CountFixedElement3D& CountFixedElement3D::operator=(
    const CountFixedElement3D& ACountFixedElement3D) {
    if (this != &ACountFixedElement3D) {
        Element3D::operator=(ACountFixedElement3D);
    }
    return *this;
}
/*************************************************************************
【函数名称】FixedAddPoint
【函数功能】若尝试调用此函数，抛出POINT_COUNT_IS_FIXED异常
【参数】const Point3D& APoint, 表示Point3D类的对象
【返回值】无
【开发者及日期】谭雯心 2024/8/5
【更改记录】
*************************************************************************/
void CountFixedElement3D::FixedAddPoint(const Point3D& APoint) {
    throw POINT_COUNT_IS_FIXED();
}
/*************************************************************************
【函数名称】FixedRemovePoint
【函数功能】若尝试调用此函数，抛出POINT_COUNT_IS_FIXED异常
【参数】size_t Index, 表示点的位置
【返回值】无
【开发者及日期】谭雯心 2024/8/5
【更改记录】
*************************************************************************/
void CountFixedElement3D::FixedRemovePoint(size_t Index) {
    throw POINT_COUNT_IS_FIXED();
}
/*************************************************************************
【函数名称】FixedRemovePoint
【函数功能】若尝试调用此函数，抛出POINT_COUNT_IS_FIXED异常
【参数】const Point3D& APoint, 表示Point3D类的对象
【返回值】无
【开发者及日期】谭雯心 2024/8/5
【更改记录】
*************************************************************************/
void CountFixedElement3D::FixedRemovePoint(const Point3D& APoint) {
    throw POINT_COUNT_IS_FIXED();
}
/*************************************************************************
【函数名称】FixedClearPoint
【函数功能】若尝试调用此函数，抛出POINT_COUNT_IS_FIXED异常
【参数】无
【返回值】无
【开发者及日期】谭雯心 2024/8/5
【更改记录】
*************************************************************************/
void CountFixedElement3D::FixedClearPoint() { 
    throw POINT_COUNT_IS_FIXED();
}
